package com.example.springcloudcontractconsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudContractConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
