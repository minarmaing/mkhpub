package com.retailbank.creditcardservice;

public enum CardType {
    GOLD;
}
