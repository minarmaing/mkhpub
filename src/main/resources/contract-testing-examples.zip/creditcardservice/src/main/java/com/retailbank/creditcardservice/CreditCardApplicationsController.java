package com.retailbank.creditcardservice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class CreditCardApplicationsController {

    @Autowired
    private final RestTemplate restTemplate;

    public CreditCardApplicationsController(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @PostMapping(value = "/credit-card-applications", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ApplyForCreditCardResponse applyForCreditCard(@RequestBody final ApplicationForCreditCard applicationForCreditCard) {
        final int citizenNumber = applicationForCreditCard.getCitizenNumber();
        final CreditCheckResponse creditCheckResponse = restTemplate.postForObject("http://localhost:8080/credit-scores", new CreditCheckRequest(citizenNumber), CreditCheckResponse.class);
        if (creditCheckResponse.getScore() == Score.HIGH && applicationForCreditCard.getCardType() == CardType.GOLD) {
            return new ApplyForCreditCardResponse(Status.GRANTED);
        }

        throw new RuntimeException("Rejected");
    }
}
