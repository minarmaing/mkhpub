package com.retailbank.creditcardservice;

public enum Score {
    HIGH
}
