package com.retailbank.creditcardservice;

public class ApplyForCreditCardResponse {
    private Status status;

    public ApplyForCreditCardResponse(Status status) {
        this.status = status;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
}
