package com.example.springcloudcontractproducer;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudContractProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
