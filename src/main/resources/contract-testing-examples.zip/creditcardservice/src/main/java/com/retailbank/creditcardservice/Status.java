package com.retailbank.creditcardservice;

public enum Status {
    GRANTED
}
