package com.retailbank.creditcheckservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditcheckserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditcheckserviceApplication.class, args);
	}

}
